@extends('front.layout')

@section('title', ($metaTitle ?: $title) . ' - Denizli Teknik')
@section('meta_description', $metaDescription ?: $subtitle)
@section('og_title', $metaTitle ?: $title)
@section('og_description', $metaDescription ?: $subtitle)
@push('json-ld')
@php
$contactBreadcrumb = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => [['@type' => 'ListItem', 'position' => 1, 'name' => 'Anasayfa', 'item' => route('home')], ['@type' => 'ListItem', 'position' => 2, 'name' => $title, 'item' => route('page.contact')]]];
@endphp
<script type="application/ld+json">@json($contactBreadcrumb)</script>
@endpush

@section('content')
<section class="page-header page-header-modern bg-color-grey page-header-md">
    <div class="container">
        <div class="row">
            <div class="col-md-12 align-self-center p-static order-2 text-center">
                <h1 class="text-dark font-weight-bold text-8">{{ $title }}</h1>
                <span class="sub-title text-dark">{{ $subtitle }}</span>
            </div>
        </div>
    </div>
</section>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-6 text-center">
            <p class="mb-3 text-dark">Herhangi bir sorunuz için bu numaradan bize ulaşabilirsiniz.</p>
            @if($footerTel)
            <p class="mb-0"><a href="tel:{{ preg_replace('/\D/', '', $footerTel) }}" class="btn btn-primary btn-lg">{{ \App\Helpers\ContentHelper::formatPhone($footerTel) }}</a></p>
            @else
            <p class="text-muted mb-0">İletişim numarası tanımlanmamış.</p>
            @endif
        </div>
    </div>
</div>
@endsection
