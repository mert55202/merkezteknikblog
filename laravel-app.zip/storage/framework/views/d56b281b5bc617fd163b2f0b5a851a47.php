<?php $__env->startSection('title', $metaTitle); ?>
<?php $__env->startSection('meta_description', $metaDescription); ?>
<?php $__env->startSection('og_title', $metaTitle); ?>
<?php $__env->startSection('og_description', $metaDescription); ?>

<?php $__env->startPush('styles'); ?>
<style>
.home-hero { min-height: 280px; }
.home-hero-bg {
    position: absolute; inset: 0;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
}
.home-hero-overlay {
    position: absolute; inset: 0;
    background: linear-gradient(to bottom, rgba(0,0,0,.4), rgba(0,0,0,.5));
}
.home-hero-content { min-height: 280px; display: flex; align-items: center; color: #fff !important; }
.home-hero-content h1,
.home-hero-content p { color: #fff !important; }
.home-hero-content h1 { text-shadow: 0 1px 3px rgba(0,0,0,.5); }
.home-hero-content p { text-shadow: 0 1px 2px rgba(0,0,0,.5); opacity: 1; }
@media (min-width: 992px) {
    .home-hero { min-height: 360px; }
    .home-hero-content { min-height: 360px; }
}
.servis-liste-satir .ratio-1x1 { --bs-aspect-ratio: 100%; }
@media (max-width: 767px) {
    .servis-liste-container .container { padding-left: 0.5rem; padding-right: 0.5rem; }
    .servis-liste-satir .d-flex { gap: 0.5rem !important; }
    .servis-liste-satir .servis-liste-resim { flex: 0 0 18% !important; }
    .servis-liste-satir .servis-liste-icerik { flex: 1 1 auto !important; min-width: 0 !important; }
    .servis-liste-satir .servis-liste-buton { flex: 0 0 auto !important; }
    .servis-liste-satir .servis-liste-buton .btn { white-space: nowrap; padding-left: 0.5rem; padding-right: 0.5rem; font-size: 0.875rem; }
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php
    $heroGorsel = \App\Models\SiteContent::getValue('hero_gorsel', 'img/landing/header_bg.jpg');
    $heroBaslik = \App\Models\SiteContent::getValue('hero_baslik', 'Denizli Servis Hizmetleri');
    $heroAltBaslik = \App\Models\SiteContent::getValue('hero_alt_baslik', 'Tüm marka beyaz eşyaların tamir bakım ve onarımını yapan servislerin listesini sizin için Paylaştık.');
?>
<section class="home-hero position-relative overflow-hidden">
    <div class="home-hero-bg" style="background-image: url('<?php echo e(\App\Helpers\ContentHelper::imageUrl($heroGorsel)); ?>');"></div>
    <div class="home-hero-overlay"></div>
    <div class="home-hero-content position-relative text-center text-white">
        <div class="container container-xl-custom py-5">
            <h1 class="font-weight-bold text-7 text-8-lg mb-3"><?php echo e($heroBaslik); ?></h1>
            <p class="text-4 text-5-lg opacity-90 mb-0"><?php echo e($heroAltBaslik); ?></p>
        </div>
    </div>
</section>

<?php if($brands->isNotEmpty()): ?>
<section class="section border-0 m-0 py-4">
    <div class="container container-xl-custom">
        <h2 class="font-weight-bold text-5 mb-4">Markalar</h2>
        <div class="row">
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2 mb-3">
                <a href="<?php echo e(route('servis.brand', $brand)); ?>" class="d-block text-center p-3 border rounded text-dark text-decoration-none bg-hover-light">
                    <span class="font-weight-semibold text-2 text-uppercase"><?php echo e($brand->name); ?></span>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="mt-2">
            <a href="<?php echo e(route('servis.index')); ?>" class="btn btn-outline-dark btn-sm">Tüm servisleri görüntüle</a>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if($categories->isNotEmpty()): ?>
<section class="section bg-color-primary border-0 m-0">
    <div class="container container-xl-custom">
        <div class="row">
            <div class="col text-center">
                <div class="owl-carousel owl-theme nav-dark stage-margin nav-style-1 m-0" data-plugin-options="{'items': 6, 'margin': 5, 'loop': false, 'nav': true, 'dots': false, 'stagePadding': 40}">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="px-3">
                        <a href="<?php echo e(route('servis.category', $cat)); ?>" class="btn btn-dark w-100 py-3 rounded-0 text-2 text-uppercase font-weight-bold"><?php echo e($cat->name); ?></a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<div class="container container-xl-custom py-4 servis-liste-container">
    <div class="row mt-5 pt-3">
        <div class="col-lg-9">
            <div class="blog-posts">
                <?php $__empty_1 = true; $__currentLoopData = $listServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $servisTel = preg_replace('/\D/', '', $service->phone ?: \App\Models\SiteContent::getValue('footer_tel', '')); ?>
                <article class="post post-large border-bottom pb-4 mb-4 servis-liste-satir">
                    <div class="d-flex flex-row align-items-center gap-3">
                        <div class="servis-liste-resim flex-shrink-0" style="flex: 0 0 20%;">
                            <a href="<?php echo e(route('servis.show', $service)); ?>" class="d-block ratio ratio-1x1 overflow-hidden bg-light">
                                <?php if($service->image): ?>
                                    <img src="<?php echo e(\App\Helpers\ContentHelper::imageUrl($service->image)); ?>" class="object-fit-cover w-100 h-100" alt="<?php echo e($service->title); ?>">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('front/img/blog/square/blog-1.jpg')); ?>" class="object-fit-cover w-100 h-100" alt="<?php echo e($service->title); ?>">
                                <?php endif; ?>
                            </a>
                        </div>
                        <div class="servis-liste-icerik flex-grow-1" style="flex: 0 0 60%; min-width: 0;">
                            <h2 class="font-weight-semibold text-5 line-height-6 mb-2"><a href="<?php echo e(route('servis.show', $service)); ?>" class="text-dark"><?php echo e($service->title); ?></a></h2>
                            <?php if($service->phone): ?><p class="text-2 mb-1"><a href="tel:<?php echo e($servisTel); ?>"><?php echo e(\App\Helpers\ContentHelper::formatPhone($service->phone)); ?></a></p><?php endif; ?>
                            <?php if($service->brands->isNotEmpty()): ?><p class="text-2 mb-1"><i class="fas fa-tag"></i> <?php echo e($service->brands->pluck('name')->join(', ')); ?></p><?php endif; ?>
                            <?php if($service->categories->isNotEmpty()): ?><p class="text-2 mb-0"><i class="far fa-folder"></i> <?php echo e($service->categories->pluck('name')->join(', ')); ?></p><?php endif; ?>
                        </div>
                        <div class="servis-liste-buton d-flex align-items-center justify-content-center flex-shrink-0" style="flex: 0 0 20%;">
                            <a href="<?php echo e($servisTel ? 'tel:' . $servisTel : route('servis.show', $service)); ?>" class="d-md-none btn btn-primary rounded-0 js-track-service-click" data-service-id="<?php echo e($service->id); ?>" data-button-type="ara">Ara</a>
                            <a href="<?php echo e(route('servis.show', $service)); ?>" class="d-none d-md-inline-flex btn btn-primary rounded-0 js-track-service-click" data-service-id="<?php echo e($service->id); ?>" data-button-type="detay"><?php echo e($readMoreText); ?></a>
                        </div>
                    </div>
                </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center py-5">
                    <p class="text-muted">Henüz servis eklenmemiş.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-3">
            <aside class="sidebar pb-4" data-plugin-sticky data-plugin-options="{'minWidth': 991, 'containerSelector': '.container', 'padding': {'top': 110}}">
                <h5 class="font-weight-semi-bold pt-4 mb-2">Kategoriler</h5>
                <div class="mb-3 pb-1">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('servis.category', $cat)); ?>"><span class="badge badge-dark badge-sm rounded-pill text-uppercase px-2 py-1 me-1 mb-1"><?php echo e($cat->name); ?></span></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <h5 class="font-weight-semi-bold pt-4 mb-2">Markalar</h5>
                <div class="mb-3 pb-1">
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('servis.brand', $b)); ?>"><span class="badge badge-dark badge-sm rounded-pill text-uppercase px-2 py-1 me-1 mb-1"><?php echo e($b->name); ?></span></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </aside>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/front/home.blade.php ENDPATH**/ ?>