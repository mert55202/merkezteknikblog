<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4">Dashboard</h1>
<div class="row">
    <?php if(auth()->user()->hasPermission('services')): ?>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Toplam Servis</h5>
                <p class="display-6"><?php echo e($servicesCount); ?></p>
                <a href="<?php echo e(route('admin.services.index')); ?>" class="btn btn-sm btn-outline-primary">Servisler</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if(auth()->user()->hasPermission('brands')): ?>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Markalar</h5>
                <p class="display-6"><?php echo e($brandsCount); ?></p>
                <a href="<?php echo e(route('admin.brands.index')); ?>" class="btn btn-sm btn-outline-primary">Markalar</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if(auth()->user()->hasPermission('categories')): ?>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Kategoriler</h5>
                <p class="display-6"><?php echo e($categoriesCount); ?></p>
                <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-sm btn-outline-primary">Kategoriler</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if(auth()->user()->hasPermission('site_contents')): ?>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">İçerik Yönetimi</h5>
                <p class="text-muted">Metin ve görseller</p>
                <a href="<?php echo e(route('admin.site-contents.index')); ?>" class="btn btn-sm btn-outline-primary">Düzenle</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if(!auth()->user()->hasPermission('services') && !auth()->user()->hasPermission('brands') && !auth()->user()->hasPermission('categories') && !auth()->user()->hasPermission('site_contents')): ?>
    <div class="col-12">
        <div class="card">
            <div class="card-body text-center py-5">
                <p class="text-muted mb-0">Hoş geldiniz, <?php echo e(auth()->user()->name); ?>. Yetkinize uygun yönetim sayfaları sol menüde listelenir.</p>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>