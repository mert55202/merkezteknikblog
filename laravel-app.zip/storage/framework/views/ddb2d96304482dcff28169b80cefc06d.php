<?php $__env->startSection('title', ($metaTitle ?: $title) . ' - Denizli Teknik'); ?>
<?php $__env->startSection('meta_description', $metaDescription ?: $subtitle); ?>
<?php $__env->startSection('og_title', $metaTitle ?: $title); ?>
<?php $__env->startSection('og_description', $metaDescription ?: $subtitle); ?>
<?php $__env->startPush('json-ld'); ?>
<?php
$contactBreadcrumb = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => [['@type' => 'ListItem', 'position' => 1, 'name' => 'Anasayfa', 'item' => route('home')], ['@type' => 'ListItem', 'position' => 2, 'name' => $title, 'item' => route('page.contact')]]];
?>
<script type="application/ld+json"><?php echo json_encode($contactBreadcrumb, 15, 512) ?></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="page-header page-header-modern bg-color-grey page-header-md">
    <div class="container">
        <div class="row">
            <div class="col-md-12 align-self-center p-static order-2 text-center">
                <h1 class="text-dark font-weight-bold text-8"><?php echo e($title); ?></h1>
                <span class="sub-title text-dark"><?php echo e($subtitle); ?></span>
            </div>
        </div>
    </div>
</section>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-6 text-center">
            <p class="mb-3 text-dark">Herhangi bir sorunuz için bu numaradan bize ulaşabilirsiniz.</p>
            <?php if($footerTel): ?>
            <p class="mb-0"><a href="tel:<?php echo e(preg_replace('/\D/', '', $footerTel)); ?>" class="btn btn-primary btn-lg"><?php echo e(\App\Helpers\ContentHelper::formatPhone($footerTel)); ?></a></p>
            <?php else: ?>
            <p class="text-muted mb-0">İletişim numarası tanımlanmamış.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/front/page/contact.blade.php ENDPATH**/ ?>