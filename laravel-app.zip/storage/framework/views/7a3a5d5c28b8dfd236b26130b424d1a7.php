<?php $__env->startSection('title', (isset($metaTitle) && $metaTitle !== '' ? $metaTitle : $title) . ' - Denizli Teknik'); ?>
<?php $__env->startSection('meta_description', (isset($metaDescription) && $metaDescription !== '' ? $metaDescription : \Illuminate\Support\Str::limit(strip_tags($content ?? ''), 160))); ?>
<?php $__env->startSection('og_title', isset($metaTitle) && $metaTitle !== '' ? $metaTitle : $title); ?>
<?php $__env->startSection('og_description', (isset($metaDescription) && $metaDescription !== '' ? $metaDescription : \Illuminate\Support\Str::limit(strip_tags($content ?? ''), 160))); ?>
<?php $__env->startPush('json-ld'); ?>
<?php
$aboutBreadcrumb = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => [['@type' => 'ListItem', 'position' => 1, 'name' => 'Anasayfa', 'item' => route('home')], ['@type' => 'ListItem', 'position' => 2, 'name' => $title, 'item' => route('page.about')]]];
?>
<script type="application/ld+json"><?php echo json_encode($aboutBreadcrumb, 15, 512) ?></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="page-header page-header-modern bg-color-grey page-header-md">
    <div class="container">
        <div class="row">
            <div class="col-md-12 align-self-center p-static order-2 text-center">
                <h1 class="text-dark font-weight-bold text-8"><?php echo e($title); ?></h1>
            </div>
            <div class="col-md-12 align-self-center order-1">
                <ul class="breadcrumb d-block text-center">
                    <li><a href="<?php echo e(route('home')); ?>"><?php echo e(\App\Models\SiteContent::getValue('nav_anasayfa', 'Anasayfa')); ?></a></li>
                    <li class="active"><?php echo e($title); ?></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<div class="container py-5">
    <div class="row align-items-center">
        <?php if($image): ?>
        <div class="col-lg-4 mb-4 mb-lg-0">
            <img src="<?php echo e(\App\Helpers\ContentHelper::imageUrl($image)); ?>" class="img-fluid rounded" alt="<?php echo e($title); ?>">
        </div>
        <?php endif; ?>
        <div class="<?php echo e($image ? 'col-lg-8' : 'col-12'); ?>">
            <div class="entry-content">
                <?php echo nl2br(e($content ?? '')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/front/page/about.blade.php ENDPATH**/ ?>