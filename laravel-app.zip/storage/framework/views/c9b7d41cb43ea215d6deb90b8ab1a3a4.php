<?php $__env->startSection('title', (isset($category) && $category ? ($category->meta_title ?: $pageTitle) : (isset($brand) && $brand ? $pageTitle : ($metaTitle ?? $pageTitle))) . ' - Denizli Teknik'); ?>
<?php $__env->startSection('meta_description', isset($category) && $category ? ($category->meta_description ?? $pageSubtitle ?? '') : (isset($brand) && $brand ? ($brand->description ?? '') : ($metaDescription ?? $pageSubtitle ?? ''))); ?>
<?php $__env->startSection('og_title', $pageTitle); ?>
<?php $__env->startSection('og_description', $metaDescription ?? $pageSubtitle ?? ''); ?>

<?php $__env->startPush('styles'); ?>
<style>
.servis-liste-satir .ratio-1x1 { --bs-aspect-ratio: 100%; }
@media (max-width: 767px) {
    .servis-liste-container .container { padding-left: 0.5rem; padding-right: 0.5rem; }
    .servis-liste-satir .d-flex { gap: 0.5rem !important; }
    .servis-liste-satir .servis-liste-resim { flex: 0 0 18% !important; }
    .servis-liste-satir .servis-liste-icerik { flex: 1 1 auto !important; min-width: 0 !important; }
    .servis-liste-satir .servis-liste-buton { flex: 0 0 auto !important; }
    .servis-liste-satir .servis-liste-buton .btn { white-space: nowrap; padding-left: 0.5rem; padding-right: 0.5rem; font-size: 0.875rem; }
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="page-header page-header-modern bg-color-grey page-header-md">
    <div class="container">
        <div class="row">
            <div class="col-md-12 align-self-center p-static order-2 text-center">
                <h1 class="text-dark font-weight-bold text-8"><?php echo e($pageTitle); ?></h1>
                <span class="sub-title text-dark"><?php echo e($pageSubtitle); ?></span>
            </div>
        </div>
    </div>
</section>
<div class="container py-4 servis-liste-container">
    <div class="row">
        <div class="<?php echo e((isset($brand) && $brand) ? 'col-12' : 'col-lg-9'); ?>">
            <div class="blog-posts">
                <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $servisTel = preg_replace('/\D/', '', $service->phone ?: \App\Models\SiteContent::getValue('footer_tel', '')); ?>
                <article class="post post-large border-bottom pb-4 mb-4 servis-liste-satir">
                    <div class="d-flex flex-row align-items-center gap-3">
                        <div class="servis-liste-resim flex-shrink-0" style="flex: 0 0 20%;">
                            <a href="<?php echo e(route('servis.show', $service)); ?>" class="d-block ratio ratio-1x1 overflow-hidden bg-light">
                                <?php if($service->image): ?>
                                    <img src="<?php echo e(\App\Helpers\ContentHelper::imageUrl($service->image)); ?>" class="object-fit-cover w-100 h-100" alt="<?php echo e($service->title); ?>">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('front/img/blog/square/blog-1.jpg')); ?>" class="object-fit-cover w-100 h-100" alt="<?php echo e($service->title); ?>">
                                <?php endif; ?>
                            </a>
                        </div>
                        <div class="servis-liste-icerik flex-grow-1" style="flex: 0 0 60%; min-width: 0;">
                            <h2 class="font-weight-semibold text-5 line-height-6 mb-2"><a href="<?php echo e(route('servis.show', $service)); ?>" class="text-dark"><?php echo e($service->title); ?></a></h2>
                            <?php if($service->phone): ?><p class="text-2 mb-1"><?php echo e(\App\Helpers\ContentHelper::formatPhone($service->phone)); ?></p><?php endif; ?>
                            <?php if($service->brands->isNotEmpty()): ?><p class="text-2 mb-1"><i class="bi bi-tag"></i> <?php echo e($service->brands->pluck('name')->join(', ')); ?></p><?php endif; ?>
                            <?php if($service->categories->isNotEmpty()): ?><p class="text-2 mb-0"><i class="far fa-folder"></i> <?php echo e($service->categories->pluck('name')->join(', ')); ?></p><?php endif; ?>
                        </div>
                        <div class="servis-liste-buton d-flex align-items-center justify-content-center flex-shrink-0" style="flex: 0 0 20%;">
                            <a href="<?php echo e($servisTel ? 'tel:' . $servisTel : route('servis.show', $service)); ?>" class="d-md-none btn btn-primary rounded-0">Ara</a>
                            <a href="<?php echo e(route('servis.show', $service)); ?>" class="d-none d-md-inline-flex btn btn-primary rounded-0"><?php echo e($readMoreText); ?></a>
                        </div>
                    </div>
                </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center py-5">
                    <p class="text-muted">Henüz servis bulunmuyor.</p>
                </div>
                <?php endif; ?>
            </div>
            <?php if($services->hasPages()): ?>
            <div class="row">
                <div class="col">
                    <?php echo e($services->links()); ?>

                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php if(!isset($brand) || !$brand): ?>
        <div class="col-lg-3">
            <div class="card border-0 bg-light">
                <div class="card-body">
                    <h5 class="card-title">Kategoriler</h5>
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2"><a href="<?php echo e(route('servis.index')); ?>">Tümü</a></li>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mb-2"><a href="<?php echo e(route('servis.category', $cat)); ?>"><?php echo e($cat->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/front/servis/index.blade.php ENDPATH**/ ?>