<?php $__env->startSection('title', ($service->meta_title ?: $service->title) . ' - Denizli Teknik'); ?>
<?php $__env->startSection('meta_description', $service->meta_description ?: Str::limit(strip_tags($service->excerpt ?? $service->content), 160)); ?>
<?php $__env->startSection('og_title', $service->meta_title ?: $service->title); ?>
<?php $__env->startSection('og_description', $service->meta_description ?: Str::limit(strip_tags($service->excerpt ?? $service->content), 160)); ?>
<?php $__env->startSection('og_type', 'website'); ?>
<?php if($service->meta_keywords): ?><?php $__env->startSection('meta_keywords', $service->meta_keywords); ?><?php endif; ?>
<?php if($service->image): ?>
<?php $__env->startPush('meta'); ?>
<meta property="og:image" content="<?php echo e(\App\Helpers\ContentHelper::imageUrl($service->image)); ?>">
<meta property="og:image:secure_url" content="<?php echo e(\App\Helpers\ContentHelper::imageUrl($service->image)); ?>">
<?php $__env->stopPush(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<section class="page-header page-header-modern bg-color-grey page-header-md">
    <div class="container">
        <div class="row">
            <div class="col-md-12 align-self-center p-static order-2 text-center">
                <h1 class="text-dark font-weight-bold text-8"><?php echo e($service->title); ?></h1>
                <span class="sub-title text-dark">
                    <?php if($service->brands->isNotEmpty()): ?><?php echo e($service->brands->pluck('name')->join(', ')); ?><?php endif; ?>
                    <?php if($service->categories->isNotEmpty()): ?> · <?php echo e($service->categories->pluck('name')->join(', ')); ?><?php endif; ?>
                    <?php if($service->published_at): ?> · <?php echo e($service->published_at->format('d.m.Y')); ?><?php endif; ?>
                </span>
            </div>
        </div>
    </div>
</section>
<div class="container py-4">
    <div class="row">
        <div class="col">
            <article class="post post-large blog-single-post border-0 m-0 p-0">
                <?php if($service->image): ?>
                <div class="post-image ms-0">
                    <img src="<?php echo e(\App\Helpers\ContentHelper::imageUrl($service->image)); ?>" class="img-fluid img-thumbnail img-thumbnail-no-borders rounded-0" alt="<?php echo e($service->title); ?>" />
                </div>
                <?php endif; ?>
                <div class="post-content ms-0 pt-4">
                    <div class="post-meta mb-3">
                        <?php if($service->phone): ?><span><a href="tel:<?php echo e(preg_replace('/\D/', '', $service->phone)); ?>" class="js-track-service-click" data-service-id="<?php echo e($service->id); ?>" data-button-type="ara"><?php echo e(\App\Helpers\ContentHelper::formatPhone($service->phone)); ?></a></span><?php endif; ?>
                        <?php if($service->address): ?><span><i class="fas fa-map-marker-alt"></i> <?php echo e($service->address); ?></span><?php endif; ?>
                        <?php if($service->brands->isNotEmpty()): ?><span><i class="bi bi-tag"></i> <?php $__currentLoopData = $service->brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(route('servis.brand', $b)); ?>"><?php echo e($b->name); ?></a><?php if(!$loop->last): ?>, <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span><?php endif; ?>
                        <?php if($service->categories->isNotEmpty()): ?><span><i class="far fa-folder"></i> <?php $__currentLoopData = $service->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(route('servis.category', $c)); ?>"><?php echo e($c->name); ?></a><?php if(!$loop->last): ?>, <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span><?php endif; ?>
                    </div>
                    <div class="entry-content">
                        <?php echo $service->content; ?>

                    </div>
                    <div class="post-block mt-5 post-share">
                        <h4 class="mb-3"><?php echo e($shareText); ?></h4>
                        <div class="d-flex gap-2">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(route('servis.show', $service))); ?>" target="_blank" class="btn btn-sm btn-primary"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://wa.me/?text=<?php echo e(urlencode($service->title . ' ' . $service->phone . ' ' . route('servis.show', $service))); ?>" target="_blank" class="btn btn-sm btn-success"><i class="fab fa-whatsapp"></i></a>
                        </div>
                    </div>
                </div>
            </article>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/front/servis/show.blade.php ENDPATH**/ ?>