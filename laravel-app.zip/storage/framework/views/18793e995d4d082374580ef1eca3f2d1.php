<?php $__env->startSection('title', 'Sayfa İçerikleri'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4">Sayfa İçerikleri</h1>
<p class="text-muted">Tüm metin ve görselleri buradan düzenleyebilirsiniz. Her metin ve her görsel için ayrı alan vardır.</p>

<form method="get" class="mb-4">
    <label class="form-label">Sayfa / Bölüm seçin</label>
    <select name="page" class="form-select w-auto d-inline-block" onchange="this.form.submit()">
        <?php
            $pageLabels = [
                'header' => 'Header (Logo & Menü)',
                'home' => 'Ana Sayfa',
                'footer' => 'Footer',
                'blog_list' => 'Blog Liste Sayfası',
                'blog_post' => 'Blog Yazı Sayfası',
                'about' => 'Hakkımızda',
                'contact' => 'İletişim',
            ];
        ?>
        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($p); ?>" <?php echo e($page == $p ? 'selected' : ''); ?>><?php echo e($pageLabels[$p] ?? $p); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</form>

<form action="<?php echo e(route('admin.site-contents.update')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="card">
        <div class="card-body">
            <?php $__empty_1 = true; $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="mb-4 pb-4 border-bottom">
                    <label class="form-label fw-bold"><?php echo e($content->label); ?></label>
                    <?php if($content->type === 'image'): ?>
                        <?php
                            $imgUrl = \App\Helpers\ContentHelper::imageUrl($content->value);
                        ?>
                        <?php if($content->value): ?>
                            <div class="mb-2"><img src="<?php echo e($imgUrl); ?>" alt="" style="max-height:100px;" onerror="this.style.display='none'"></div>
                        <?php endif; ?>
                        <input type="file" name="<?php echo e($content->key); ?>" class="form-control" accept="image/*">
                        <small class="text-muted">Yeni yüklemezseniz mevcut görsel kalır.</small>
                    <?php elseif($content->type === 'textarea'): ?>
                        <textarea name="<?php echo e($content->key); ?>" class="form-control" rows="4"><?php echo e($content->value); ?></textarea>
                    <?php else: ?>
                        <input type="text" name="<?php echo e($content->key); ?>" class="form-control" value="<?php echo e($content->value); ?>">
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted">Bu sayfa için tanımlı içerik yok. Veritabanında site_contents tablosuna kayıt ekleyebilir veya seed çalıştırabilirsiniz.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php if($contents->isNotEmpty()): ?>
        <button type="submit" class="btn btn-primary mt-3">Tümünü Kaydet</button>
    <?php endif; ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/site-contents/index.blade.php ENDPATH**/ ?>